--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Bix is a python game engine made by Vahin Vamsidhar Masavarapu on December 20th 2025.

it is very simple and has only parts/cubes which differ in size , position and color.

============================================================================================================================================================================================

Rules to code scripts - 

DO NOT SET 'CanCollide' TO FALSE - THIS WILL LEAD TO INVISIBLE PARTS. CANCOLLIDE STOPS RAYCAST PARTICLES FROM DETECTING THE PART.

use the example script to learn BIX scripting, it follows python syntax.

all scripts must contain '.bix' file extension. 

all scripts must be in ScriptService.

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Rules to make parts - 

DO NOT SET 'CanCollide' TO FALSE - THIS WILL LEAD TO INVISIBLE PARTS. CANCOLLIDE STOPS RAYCAST PARTICLES FROM DETECTING THE PART.

use the example parts to learn part syntax.

all parts must contain '.part' file extension

============================================================================================================================================================================================

STEPS TO RUN YOUR GAME

in Command Prompt(Windows) - Change Directory (cd) to your Main folder (Bix).

Make sure python is installed

Run 'python Main.py'

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

NOTES - 

You may view and edit the code but when redistributing give credit to me with all links (GitHub page - https://github.com/vahinT, Roblox Username - @VahinRob, Scratch Username - @vahinm)

If u encounter a bug, put a issue on GitHub, i may / may not resolve it.

Thank you for using my game engine.


