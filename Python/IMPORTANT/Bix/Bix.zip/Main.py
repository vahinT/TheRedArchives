from Engine.engine import Engine

def main():
    engine = Engine()
    engine.run()

if __name__ == "__main__":
    main()
